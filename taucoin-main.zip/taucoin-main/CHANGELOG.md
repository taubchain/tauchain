# Changelog

All notable changes to TauCoin will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- GitHub Actions CI/CD pipeline
- Comprehensive documentation and README
- Security policy and vulnerability reporting process
- Contributing guidelines and issue templates

### Changed
- Improved project structure and organization
- Enhanced build system documentation

## [2.0.3] - 2024-12-06

### Added
- New `torrent_file_with_hashes()` function for creating .torrent files with piece layers
- `file_prio_alert` posted when file priorities are updated
- Missing Python binding for `event_t`
- Convenience header `libtorrent/libtorrent.hpp`
- `std::hash<>` specialization for `info_hash_t`
- Work-around for systems without `fseeko()` (Android support)

### Changed
- Increased default `max_allowed_in_request_queue`
- Strengthened SSRF mitigation for web seeds

### Fixed
- Issue where `set_piece_hashes()` would not propagate file errors
- Loading non-ascii filenames on Windows with torrent_info constructor (2.0 regression)
- Integer overflow in hash_picker and properly restrict max file sizes in torrents

## [2.0.2] - 2024-11-15

### Added
- `v1()` and `v2()` functions to `torrent_info`
- Improved `client_data_t` ergonomics

### Fixed
- `piece_layers()` to work for single-piece files
- Python binding regression in session constructor flags
- Unaligned piece requests in mmap_storage
- Issue with concurrent access to part files

## [2.0.1] - 2024-10-20

### Added
- Function to ask a `file_storage` whether it's v2 or not
- New setting to enable `SetFileValidData()` on Windows (disabled by default)

### Fixed
- Attribute in single-file v2 torrent creation
- Padding for empty files in v2 torrent creation
- Mtime field when creating single-file v2 torrents
- Performance regression in checking files

## [2.0.0] - 2024-09-30

### Added
- **Blockchain Module**: Complete blockchain infrastructure with transaction processing
- **Communication Module**: Peer-to-peer messaging system with friend management
- **Community Features**: Create and manage blockchain-based communities
- **Proof of Transaction (PoT)**: Revolutionary consensus mechanism that rewards transaction activity
- **Cross-platform Support**: Linux, macOS, and Windows compatibility
- **Comprehensive APIs**: Both blockchain and communication functionality
- **Security Features**: Advanced cryptographic protocols and secure key management

### Changed
- **Breaking**: Moved `session_flags` to `session_params`
- **Breaking**: Entry class is now a standard variant type
- **Breaking**: Use `std::string_view` instead of boost counterpart
- **Breaking**: Now requires C++17 to build
- **Breaking**: Deprecated `set_file_hash()` in torrent creator
- **Breaking**: Deprecated mutable access to `info_section` in `torrent_info`

### Removed
- Dependency on iconv
- Support for C++14 and earlier

### Security
- Enhanced cryptographic protocols for blockchain transactions
- Secure peer-to-peer communication with end-to-end encryption
- Improved key management and storage

## [1.9.x] - Legacy Releases

For information about releases prior to 2.0.0, please refer to the original ChangeLog file.

---

## Release Notes

### Version 2.0.0 - Major Release

This is a major release that introduces blockchain functionality and peer-to-peer communication features to the TauCoin platform. The release includes breaking changes and requires C++17.

#### Migration Guide

**For developers upgrading from 1.9.x:**

1. **C++ Standard**: Update your build system to use C++17
2. **API Changes**: Review the API documentation for breaking changes
3. **Dependencies**: Update Boost and other dependencies as specified in the build guide
4. **Configuration**: Update session configuration to use new parameter structure

**New Features Overview:**

- **Blockchain**: Full blockchain implementation with Proof of Transaction (PoT) consensus
- **Communication**: Secure messaging system with friend management
- **Communities**: Create and manage decentralized communities
- **APIs**: Comprehensive C++ APIs for both blockchain and communication features

#### Known Issues

- Performance optimization ongoing for large-scale deployments
- Mobile platform support in development
- Some advanced features still in beta

#### Acknowledgments

Special thanks to all contributors who made this major release possible, including the original libtorrent team whose excellent foundation enabled this blockchain evolution.

---

## Support

For questions about specific releases:
- Check the [documentation](docs/)
- Review [GitHub Issues](https://github.com/taucoin/taucoin/issues)
- Join [GitHub Discussions](https://github.com/taucoin/taucoin/discussions)