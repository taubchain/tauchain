# DHT development log

## 2022.03.08

    TODO list

### 1. put-push & relay solution: x->r->y, y don't respond to r.

### 2. server node crush issue: coredump generated.

### 3. android UPNP: android UI sets 'non-referrable' into false if UPNP is mapped.

### 4. store non-referrable endpoints in another table.

### 5. routing table snapshot.

## 2022.03.10

### 1. debug task: tempoture endpoints timeouts unitl they are removed.

### 2. put-push & relay solution: x->r->y, y don't respond to r.

### 3. store non-referrable endpoints in another table. 

### 4. prefix get.

### 5. android UPNP: android UI sets 'non-referrable' into false if UPNP is mapped.

### 6. routing table snapshot.

## 2022.03.11

### 1. new register protocol

## 2022.06.22

### 0. dht item target

### 1. get item protocol: traffic control, invoke-window & invoke-limit

### 2. put item protocol: just put item into ourself capture swarm and remove relay logic
