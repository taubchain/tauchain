1. 添加模块暂停恢复相关接口(doze控制)
2. put/get all state
