# Contributing to TauCoin

Thank you for your interest in contributing to TauCoin! This document provides guidelines and information for contributors.

## Code of Conduct

By participating in this project, you agree to abide by our Code of Conduct. Please treat all community members with respect and create a welcoming environment for everyone.

## Getting Started

### Development Environment Setup

1. **Fork and Clone**
   ```bash
   git clone https://github.com/YOUR_USERNAME/taucoin.git
   cd taucoin
   ```

2. **Set up Development Environment**
   Follow the [Building Guide](docs/building.md) to set up your development environment.

3. **Create a Branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

## How to Contribute

### Reporting Bugs

1. Check existing issues to avoid duplicates
2. Use the bug report template
3. Provide detailed reproduction steps
4. Include environment information

### Suggesting Features

1. Check existing feature requests
2. Use the feature request template
3. Explain the use case and benefits
4. Consider implementation complexity

### Code Contributions

#### Before You Start
- Discuss major changes in an issue first
- Check if someone else is already working on it
- Ensure your idea aligns with project goals

#### Development Process

1. **Write Code**
   - Follow existing code style and conventions
   - Add appropriate comments and documentation
   - Keep changes focused and atomic

2. **Testing**
   - Add unit tests for new functionality
   - Ensure all existing tests pass
   - Test on multiple platforms if possible

3. **Documentation**
   - Update relevant documentation
   - Add API documentation for new functions
   - Update README if needed

4. **Commit Guidelines**
   ```
   type(scope): brief description
   
   Longer description if needed
   
   Fixes #123
   ```
   
   Types: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`

5. **Submit Pull Request**
   - Use the PR template
   - Link related issues
   - Provide clear description of changes

## Code Style Guidelines

### C++ Style
- Follow existing code formatting
- Use meaningful variable and function names
- Add comments for complex logic
- Prefer const correctness
- Use RAII principles

### API Design
- Maintain backward compatibility when possible
- Use clear, descriptive function names
- Provide comprehensive error handling
- Document return values and error codes

## Testing

### Running Tests
```bash
# Build and run tests
b2 test

# Run specific test suite
b2 test//blockchain_tests
```

### Writing Tests
- Write unit tests for new functions
- Include edge cases and error conditions
- Use descriptive test names
- Keep tests independent and deterministic

## Documentation

### Code Documentation
- Document all public APIs
- Include usage examples
- Explain complex algorithms
- Update API reference when needed

### User Documentation
- Update README for user-facing changes
- Add examples for new features
- Keep building instructions current

## Review Process

### What We Look For
- Code quality and style consistency
- Appropriate test coverage
- Clear documentation
- Backward compatibility
- Performance considerations

### Review Timeline
- Initial review within 1-2 weeks
- Follow-up reviews within a few days
- Merge after approval from maintainers

## Community

### Communication Channels
- GitHub Issues for bugs and features
- GitHub Discussions for general questions
- Pull Request comments for code review

### Getting Help
- Check existing documentation first
- Search closed issues for similar problems
- Ask questions in GitHub Discussions
- Be patient and respectful

## Recognition

Contributors are recognized in:
- Git commit history
- Release notes for significant contributions
- AUTHORS file for major contributors

## License

By contributing to TauCoin, you agree that your contributions will be licensed under the same BSD 3-Clause License that covers the project.

---

Thank you for contributing to TauCoin! 🚀