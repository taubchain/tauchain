# TauCoin

<div align="center">
  <img src="docs/img/logo-tau.png" alt="TauCoin Logo" width="200"/>
  
  [![Build Status](https://img.shields.io/badge/build-passing-brightgreen.svg)](https://github.com/taucoin/taucoin)
  [![License](https://img.shields.io/badge/license-BSD--3--Clause-blue.svg)](LICENSE)
  [![Platform](https://img.shields.io/badge/platform-Linux%20%7C%20macOS%20%7C%20Windows-lightgrey.svg)]()
  [![Language](https://img.shields.io/badge/language-C%2B%2B-orange.svg)]()
</div>

## Overview

TauCoin is a next-generation blockchain platform that combines decentralized communication with blockchain technology. Built on a robust C++ foundation, TauCoin introduces the innovative **Proof of Transaction (PoT)** consensus mechanism, enabling secure peer-to-peer communication while maintaining a scalable blockchain infrastructure for digital transactions and community governance.

**Learn More**: [Official Website](https://taucoin.net/) | [Whitepaper](https://taucoin.net/docs/Tau%20Whitepaper%20v1.pdf)

### Key Features

- **🔗 Proof of Transaction (PoT)**: Revolutionary consensus mechanism that rewards transaction activity
- **💬 Decentralized Communication**: Built-in peer-to-peer messaging system with friend management
- **🏘️ Community Governance**: Create and manage decentralized communities with voting mechanisms  
- **🔒 Security First**: Advanced cryptographic protocols and secure key management
- **⚡ High Performance**: Optimized C++ implementation for speed and efficiency
- **🌐 Cross-Platform**: Support for Linux, macOS, and Windows

## Proof of Transaction (PoT) Consensus

TauCoin introduces **Proof of Transaction (PoT)**, a revolutionary consensus mechanism that rewards network participants based on their transaction activity rather than computational power or stake. This innovative approach:

- **Incentivizes Usage**: Users are rewarded for actively using the network
- **Energy Efficient**: No energy-intensive mining or large stake requirements
- **Fair Distribution**: Rewards are distributed based on actual network contribution
- **Scalable**: Transaction activity naturally scales with network growth

For detailed technical specifications, see our [Whitepaper](https://taucoin.net/docs/Tau%20Whitepaper%20v1.pdf).

## Architecture

TauCoin consists of two main components:

### Blockchain Module
- **Proof of Transaction (PoT)**: Innovative consensus where transaction activity drives block production
- **Transaction Processing**: Submit and validate transactions with dynamic fee management
- **Block Management**: Create, validate, and synchronize blocks using PoT consensus
- **Account Management**: Secure wallet functionality with balance tracking
- **Community Features**: Create and manage blockchain-based communities with PoT governance

### Communication Module  
- **Friend Management**: Add, remove, and manage trusted contacts
- **Secure Messaging**: End-to-end encrypted peer-to-peer communication
- **Device Synchronization**: Multi-device message synchronization
- **Presence System**: Track online status and last seen information

## Quick Start

### Prerequisites

- **Operating System**: Ubuntu 18.04+ (recommended), macOS, or Windows
- **Compiler**: GCC 10+ or equivalent C++17 compatible compiler
- **Dependencies**: Boost 1.76.0, OpenSSL 1.1.1k, LevelDB 1.23

### Building from Source

1. **Clone the repository**
   ```bash
   git clone https://github.com/taucoin/taucoin.git
   cd taucoin
   ```

2. **Install dependencies** (Ubuntu example)
   ```bash
   # Install GCC
   sudo add-apt-repository ppa:ubuntu-toolchain-r/test
   sudo apt update
   sudo apt install gcc-10 g++-10
   
   # Build dependencies (see docs/building.md for detailed instructions)
   ```

3. **Build the project**
   ```bash
   b2
   ```

4. **Run examples**
   ```bash
   cd examples
   b2
   ```

For detailed build instructions, see [Building Guide](docs/building.md).

## API Reference

TauCoin provides comprehensive APIs for both blockchain and communication functionality:

### Blockchain APIs
- `create_new_community()` - Create blockchain-based communities
- `submit_transaction()` - Submit transactions to the network
- `get_account_info()` - Retrieve account balance and information
- `get_block_by_hash()` - Query blocks by hash or number
- `get_mining_time()` - Get PoT consensus timing information
- `get_top_tip_block()` - Get highest transaction activity blocks

### Communication APIs  
- `add_new_friend()` - Add trusted contacts
- `add_new_message()` - Send encrypted messages
- `get_friend_info()` - Retrieve contact information

For complete API documentation, see [libTAU APIs](docs/libTAU_APIS.md).

## Use Cases

- **Decentralized Social Networks**: Build social platforms where user activity is rewarded through PoT
- **Community Governance**: Create DAOs with transaction-based voting and treasury management
- **Secure Messaging**: Private communication with blockchain-verified identities and PoT incentives
- **Digital Asset Management**: Issue and trade custom tokens with PoT-driven liquidity
- **Activity-Based Rewards**: Applications that reward user engagement through transaction activity

## Documentation

- [Building Guide](docs/building.md) - Compilation and setup instructions
- [API Reference](docs/libTAU_APIS.md) - Complete API documentation
- [Contributing](docs/contributing.rst) - How to contribute to the project
- [Examples](docs/examples.rst) - Code examples and tutorials

## Community & Support

- **Issues**: Report bugs and request features on [GitHub Issues](https://github.com/taucoin/taucoin/issues)
- **Discussions**: Join community discussions on [GitHub Discussions](https://github.com/taucoin/taucoin/discussions)
- **Website**: Visit our [official website](https://taucoin.net/)
- **Whitepaper**: Read the [TauCoin Whitepaper](https://taucoin.net/docs/Tau%20Whitepaper%20v1.pdf)

## Contributing

We welcome contributions from the community! Please read our [Contributing Guide](docs/contributing.rst) to get started.

### Development Process
1. Fork the repository
2. Create a feature branch
3. Make your changes with tests
4. Submit a pull request

## License

TauCoin is released under the [BSD 3-Clause License](LICENSE). See the LICENSE file for details.

## Acknowledgments

TauCoin builds upon the excellent work of the libtorrent project and incorporates various open-source cryptographic libraries. We thank all contributors and the open-source community.

---

<div align="center">
  <strong>Built with ❤️ by the TauCoin Community</strong>
</div>